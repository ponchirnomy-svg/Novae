# Nova AI — starter con Gemini

Este paquete conecta la interfaz de Nova AI a Gemini **a través de un servidor**. No incluye tu clave. La función de chat por texto está preparada; análisis de imágenes y generación de APK todavía no están implementados.

## Para trabajar solo desde Android

La forma más sencilla es subir estos archivos a un repositorio de GitHub desde Chrome y desplegarlo como Web Service en Render. No necesitas computadora, pero sí tendrás que usar las páginas de GitHub y Render.

1. En GitHub crea un repositorio nuevo llamado `nova-ai`. Si aparece la opción, puedes dejarlo privado.
2. Descomprime este ZIP con la app Archivos de Android y sube el contenido de la carpeta al repositorio, manteniendo `server.js`, `package.json` y la carpeta `public` en la raíz. **No subas nunca un archivo `.env` con tu clave.**
3. En Render crea un **New Web Service** y conecta el repositorio.
4. Configura:
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Plan: Free para pruebas, si está disponible en tu cuenta.
5. En la sección **Environment** de Render agrega una variable:
   - Key: `GEMINI_API_KEY`
   - Value: pega tu clave de Gemini allí, directamente en Render. No la pegues en el chat ni en GitHub.
6. Pulsa Deploy y espera a que termine. Abre la dirección `https://...onrender.com` que te dé Render. La página `/api/health` debería mostrar `{"ok":true,"app":"Nova AI"}`.
7. Prueba enviar un mensaje en la página principal.

## Límites importantes

- El plan gratuito de Render puede suspender el servicio después de 15 minutos sin actividad; el primer mensaje posterior puede tardar en despertar el servidor.
- Gemini API tiene límites según modelo, cuenta y condiciones vigentes. Revisa el uso en Google AI Studio.
- Este starter es para pruebas: antes de hacerlo público conviene agregar controles de abuso y límites por usuario. La clave se mantiene en el servidor, pero cualquier visitante podría consumir la cuota si publicas el servicio sin controles.
- La interfaz aún no envía imágenes a Gemini, y este paquete no es una APK.

Documentación oficial:
- Gemini API: https://ai.google.dev/gemini-api/docs
- Render despliegue: https://render.com/docs/your-first-deploy
- Límites del plan gratuito: https://render.com/docs/free
